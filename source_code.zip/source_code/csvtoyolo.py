import pandas as pd
import sklearn
from sklearn.preprocessing import MinMaxScaler

# directory ot save the labels
dest = 'C:\\Users\\Kumar\\Documents\\Hackathons\\Smartathon\\dataset\\labels' 

# the csv file is converted to a pandas dataframe..
df = pd.read_csv('C:\\Users\\Kumar\\Documents\\Hackathons\\Smartathon\\dataset\\train.csv')

# Data exploration
df.columns
df['name'].unique().size
df['class'].unique()
df1 = df.copy()

df1.drop(['image_path', 'name'], axis = 1, inplace = True)
df1.columns

df1.shape
img_size = [1920, 1080]
df1.dtypes
print(img_size[1])
df1.head()

# The lists to hold the yolo parameters..
w = []
h = []
x = []
y = []
for i in range(19950):
    
    width = (df1.at[i, 'xmax'] - df1.at[i, 'xmin'])/img_size[1]
    height = (df1.at[i, 'xmax'] - df1.at[i, 'xmin'])/img_size[0]
    
    x.append((df1.at[i, 'xmax'] + df1.at[i, 'xmin']) / 2)/img_size[1]
    y.append((df1.at[i, 'ymax'] + df1.at[i, 'ymin']) / 2)/img_size[0]
    
    w.append(width)
    h.append(height)


'''print(w)
print(h)
print(x)
print(y)
'''
df.columns
df.shape[0]

df['image_path'] = df['image_path'].map(lambda x: x.rstrip('.jpg'))

unique_names = df['image_path'].unique()
df['image_path'].unique().size

for i in range(7874):
    with open (f'{dest}/{unique_names[i]}.txt', 'x') as f:
        f.write('')

'''    
df.at[19948, 'image_path']
df.at[19949, 'image_path']
'''

for i in range(19950):
    for j in range(7874):
        if df.at[i, 'image_path'] == unique_names[j]:
            with open (f'{dest}/{unique_names[j]}.txt', 'a') as f:
                f.write(f'{df.at[i, "class"]} {x[i]} {y[i]} {w[i]} {h[i]}\n')
                
                