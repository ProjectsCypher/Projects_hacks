import pandas as pd
import os


df = pd.read_csv('C:\\Users\\Kumar\\Documents\\Hackathons\\Smartathon\\dataset\\test.csv')

source = 'C:\\Users\\Kumar\\Documents\\Hackathons\\Smartathon\\dataset\\images'
dest = 'C:\\Users\\Kumar\\Documents\\Hackathons\\Smartathon\\dataset\\test'

for image in df['image_path']:
    for filename in os.listdir(source):
        if filename == image:
            os.rename(f'{source}/{filename}', f'{dest}/{filename}')
            

